import PySimpleGUI as sg
from PIL import Image, ImageTk

def image4():
    seg1 = [ 
    [
        sg.Button("<< Back to Menu", key = "back3")
    ],

    [ 

       sg.Text("Image 3"), 

    ], 

    [ 

        sg.Button("Load Image") 

    ], 

    [ 

        sg.Text("Select an Operation:\n") 

    ], 

    [ 

       sg.Button('Image enhance',  key="-enhance3-"), 

       sg.Button('Image add effect', key="-effect3-")
    ],
    
    [
       
       sg.Button('Image add word', key ="-word3-"),

       sg. Button('Image add effect and word',  key="-mix3-") 

    ] 

    ] 

 

    seg2 = [ 

    [sg.Text("OUTPUT")], 

    [sg.Text("Image 3:")], 

    [sg.Image(key="-IMAGE-")], 

    ] 

    layout3 = [ 

    [ 

        sg.Column(seg1), 

        sg.VSeperator(), 

        sg.Column(seg2), 

    ] 

    ] 

 

    wind = sg.Window("my Application", layout3,size=(800, 400)) #.read() 

 

    while True: 

        event, values = wind.read() 

        if event == "Load Image": 

            image = Image.open('g.png') 

            image.thumbnail((400, 300)) 

               

        if event == "-enhance3-":

                image = Image.open('g_enhance.jpg')
                image.thumbnail((400, 300)) 
        if event == "-effect3-":

                image = Image.open('g_effect.jpg')
                image.thumbnail((400, 300)) 

        if event == "-word3-": 

                image = Image.open('g_text.jpg')
                image.thumbnail((400, 300)) 
                
        if event == "-mix3-": 

                image = Image.open('g_effectntext.jpg')
                image.thumbnail((400, 300)) 
                
        if event == "back3" or event == sg.WIN_CLOSED:
            break
        else:
            break

    photo_img = ImageTk.PhotoImage(image)       

    wind["-IMAGE-"].update(data=photo_img)

    wind.close()