import PySimpleGUI as sg


def image2():
    layout = [[sg.Text("This is Image 1", key="new")],
              [sg.Button("Back", key="back")],
              ]
    window = sg.Window("Image 1 Window", layout, modal=True, size=(100, 100))

    while True:
        event, values = window.read()
        if event == "Exit" or event == sg.WIN_CLOSED:
            break
        else:
            break
        
    window.close()
